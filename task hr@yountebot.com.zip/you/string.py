text = input("Enter the string: ") 
reversed_text = "".join(reversed(text))  
print(reversed_text)