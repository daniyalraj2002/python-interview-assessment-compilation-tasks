def find_missing_number(n, numbers):
    """Find the missing number in a list of numbers from 1 to n."""
    expected_sum = n * (n + 1) // 2  
    actual_sum = sum(numbers)          
    return expected_sum - actual_sum   


n = int(input("Enter the value of n: "))

numbers = list(range(1, n + 1))


missing = 3  
numbers.remove(missing)

print(f"List of numbers with one missing: {numbers}")

missing_number = find_missing_number(n, numbers)10
print(f"The missing number is: {missing_number}")