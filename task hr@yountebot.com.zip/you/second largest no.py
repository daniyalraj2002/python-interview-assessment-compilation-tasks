def find_second_largest(numbers):
    if len(numbers) < 2:
        return None  

    first = second = float('-inf')  
    for number in numbers:
        if number > first:
            second = first  
            first = number   
        elif first > number > second:
            second = number  

    return second if second != float('-inf') else None  

example_list = [10, 20, 4, 45, 99, 99]
second_largest = find_second_largest(example_list)
if second_largest is not None:
    print(f"The second largest number is: {second_largest}")
else:
    print("There is no second largest number.")