from collections import Counter

def most_frequent_element(lst):
    if not lst: 
        return None
    count = Counter(lst)
    

    most_common_element, most_common_count = count.most_common(1)[0]
    
    return most_common_element

example_list = [1, 2, 3, 2, 4, 3, 2, 5, 1]
result = most_frequent_element(example_list)
print(f"The most frequently occurring element is: {result}") 


